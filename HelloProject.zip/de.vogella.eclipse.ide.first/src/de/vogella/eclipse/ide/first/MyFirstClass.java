package de.vogella.eclipse.ide.first;

public class MyFirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Eclipse!");

	}

}
